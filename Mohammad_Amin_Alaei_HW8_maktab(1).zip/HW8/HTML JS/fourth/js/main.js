const register = document.getElementById('register');
const email = document.getElementById('email');
let emailValid;

const validating = (event) => {
    event.preventDefault();
    const phone = document.getElementById('phone');
    const fName = document.getElementById('fName').value;
    const lName = document.getElementById('lName').value;
    const password = document.getElementById('password');
    const vPassword = document.getElementById('vPassword');
    const male = document.getElementById('male');
    const female = document.getElementById('female');
    let gender;
    const question = selection.options[selection.selectedIndex].value;
    const anwser = document.getElementById("anwser").value;
    const passValid = document.getElementById('passValid');
    const vPassValid = document.getElementById('vPassValid');
    const phoneValidator = document.getElementById('phoneValid');

    const phPass = document.createElement('p');
    const vPass = document.createElement('p');
    const vVPass = document.createElement('p');

    phPass.setAttribute('class', 'phPass');
    const test = document.querySelectorAll('.phPass');

    vPass.setAttribute('class', 'vPass')
    const test2 = document.querySelectorAll('.vPass');

    vVPass.setAttribute('class', 'vVpass');
    const test3 = document.querySelectorAll('.vVpass');


    let phoneValid;
    let passwordValid;
    let vpasswordValid;

    male.checked == true ? gender = male.value : gender = female.value;

    if (phone.value[0] !== '0' && phone.value.length === 10) {
        phone.style.border = '1px solid #ccc';
        phoneValid = true;
        if (test) {
            test.forEach(item => item.remove());
        }
    } else {
        phone.style.border = '1px solid red';
        phoneValid = false;
        phPass.innerHTML = 'InValid Phone My Friend';
        phoneValidator.append(phPass);
    }

    if (password.value.length >= 7) {
        password.style.border = '1px solid #ccc';
        passwordValid = true;
        if (test2) {
            test2.forEach(item => item.remove());
        }
    } else {
        password.style.border = '1px solid red';
        vPass.innerHTML = 'Password must be at least 8 digits';
        passwordValid = false;
        passValid.append(vPass);
    }

    if (password.value === vPassword.value && vPassword.value !== '') {
        vpasswordValid = true;
        vPassword.style.border = '1px solid #ccc';
        if (test3) {
            test3.forEach(item => item.remove());
        }
    } else {
        vpasswordValid = false;
        vPassword.style.border = '1px solid red';
        vVPass.innerHTML = 'InValid Verification Password My Friend';
        vPassValid.append(vVPass);

    }

    if (phoneValid && emailValid && passwordValid && vpasswordValid) {
        console.log(`First Name : ${fName}\n
        Last Name : ${lName}\nPassword: ${password.value}\nGender: ${gender}\nEmail: ${email.value}
        \nPhone: ${phone.value}\nQuestion: ${question}\nAswser: ${anwser}`);
    }
}

register.disabled = true
email.addEventListener('change', () => {

    const emails = email.value.split('@');

    if (emails.length >= 2 && emails[1].length >= 4 && emails[1].includes('.')) {
        register.disabled = false;
        emailValid = true;
        email.style.border = '1px solid #ccc';

    } else {
        register.disabled = true;
        email.style.border = '1px solid red'
    }

});

register.addEventListener('click', validating)


